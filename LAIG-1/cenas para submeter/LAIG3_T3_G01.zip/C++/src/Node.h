#pragma once

#include <string>
#include <vector>
#include "Primitiva.h"
#include "Appearance.h"
#include "Animation.h"


using namespace std;

class Node {
public:
	Node(string id);
	string id;
	Appearance *appearance;
	float T[16]; //matriz de transforma��es
	vector<string> children; //vector de ids dos filhos
	vector<Primitiva*> primitivas;
	bool displayList;
	GLuint displayListID;
	Animation* animation;
};